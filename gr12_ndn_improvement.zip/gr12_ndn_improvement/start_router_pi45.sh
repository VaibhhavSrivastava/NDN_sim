#!/bin/bash
nohup python3 -u router/router45.py > router45.log 2>&1 &