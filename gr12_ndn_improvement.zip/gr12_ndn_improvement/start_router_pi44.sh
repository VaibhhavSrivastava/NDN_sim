#!/bin/bash
nohup python3 -u router/router44.py > router44.log 2>&1 &