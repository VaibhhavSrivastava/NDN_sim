#!/bin/bash
nohup python3 -u router/router25.py > router25.log 2>&1 &