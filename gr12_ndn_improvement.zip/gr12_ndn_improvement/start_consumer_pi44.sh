#!/bin/bash
python3 node/device2_44_consumer.py 