#!/bin/bash
python3 node/device3_45_consumer.py