#!/bin/bash
nohup python3 -u router/router43.py > router43.log 2>&1 &