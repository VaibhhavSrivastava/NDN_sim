#!/bin/bash
nohup python3 -u node/device1_43_producer.py > device_1_43_producer.log 2>&1 & 